// ==========================
// Portfolio.jsx - Premium Portfolio Page
// ==========================

import React from "react";

export const Portfolio = () => {
  const projects = [
    { id: 1, title: "Wedding Shoot", img: "https://source.unsplash.com/collection/190727/1" },
    { id: 2, title: "Corporate Event", img: "https://source.unsplash.com/collection/190727/2" },
    { id: 3, title: "Music Video", img: "https://source.unsplash.com/collection/190727/3" },
    { id: 4, title: "Commercial Shoot", img: "https://source.unsplash.com/collection/190727/4" },
    { id: 5, title: "Product Photography", img: "https://source.unsplash.com/collection/190727/5" },
    { id: 6, title: "Fashion Shoot", img: "https://source.unsplash.com/collection/190727/6" },
  ];

  return (
    <div className="font-sans text-gray-900 bg-white">

      {/* Portfolio Hero */}
      <section className="relative w-full h-64 md:h-80 flex items-center justify-center bg-red-600 text-white mb-12">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold">Our Portfolio</h1>
      </section>

      {/* Portfolio Grid */}
      <section className="px-4 md:px-6 max-w-7xl mx-auto pb-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {projects.map(project => (
            <div key={project.id} className="relative group rounded-3xl overflow-hidden shadow-2xl">
              <img src={project.img} alt={project.title} className="w-full h-64 sm:h-72 md:h-80 object-cover transform group-hover:scale-110 transition duration-500" />
              <div className="absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-25 transition"></div>
              <div className="absolute bottom-4 left-4 text-white opacity-0 group-hover:opacity-100 transition duration-500">
                <h3 className="text-xl sm:text-2xl font-bold">{project.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};