import React from "react";
import { motion } from "framer-motion";

export const Home = () => {
  return (
    <div className="font-sans text-gray-900 bg-white">
      {/* Hero Section */}
      <section className="relative w-full flex items-center justify-center bg-gradient-to-br from-red-700 to-red-500 overflow-hidden h-[90vh] md:h-[100vh]">
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-center text-white z-10 px-4 md:px-6"
        >
          <h1 className="text-5xl sm:text-6xl md:text-7xl font-extrabold mb-4 drop-shadow-lg">Red Velvet Studios</h1>
          <p className="text-lg sm:text-xl md:text-2xl mb-6 max-w-2xl mx-auto drop-shadow">
            Premium Event Photography & Cinematic Videography for Unforgettable Moments
          </p>
          <a href="/portfolio" className="px-8 sm:px-10 py-4 bg-white text-red-600 font-semibold rounded-2xl shadow-2xl hover:shadow-red-500/50 transition transform hover:-translate-y-1 inline-block">
            Explore Portfolio
          </a>
        </motion.div>
        <motion.div
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
          className="absolute inset-0 opacity-25 bg-[url('https://images.unsplash.com/photo-1506765515384-028b60a970df?auto=format&fit=crop&w=1470&q=80')] bg-cover bg-center"
        />
      </section>

      {/* Services Section */}
      <section className="py-20 md:py-28 px-6 max-w-7xl mx-auto">
        <h2 className="text-4xl sm:text-5xl font-extrabold text-center mb-16">Our Premium Services</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10">
          <motion.div whileHover={{ scale: 1.05 }} className="bg-white shadow-2xl rounded-3xl p-8 text-center border-t-4 border-red-600">
            <h3 className="text-2xl sm:text-3xl font-semibold mb-4">Event Photography</h3>
            <p className="text-gray-700 text-base sm:text-lg">Capture every emotion and moment with cinematic precision, from weddings to corporate events.</p>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} className="bg-white shadow-2xl rounded-3xl p-8 text-center border-t-4 border-red-600">
            <h3 className="text-2xl sm:text-3xl font-semibold mb-4">Videography</h3>
            <p className="text-gray-700 text-base sm:text-lg">Cinematic storytelling, highlight reels, brand films, and fully edited professional videos.</p>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} className="bg-white shadow-2xl rounded-3xl p-8 text-center border-t-4 border-red-600">
            <h3 className="text-2xl sm:text-3xl font-semibold mb-4">Production Shoots</h3>
            <p className="text-gray-700 text-base sm:text-lg">Commercials, music videos, product promotions — high-end production with modern flair.</p>
          </motion.div>
        </div>
      </section>

      {/* Featured Projects Section */}
      <section className="py-20 bg-gray-50 px-6">
        <h2 className="text-4xl sm:text-5xl font-extrabold text-center mb-16">Featured Projects</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {[...Array(6)].map((_, i) => (
            <motion.div key={i} whileHover={{ scale: 1.05 }} className="relative h-64 sm:h-72 md:h-80 rounded-3xl overflow-hidden shadow-2xl">
              <img src={`https://source.unsplash.com/collection/190727/${i}`} alt={`Project ${i+1}`} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/25 opacity-0 hover:opacity-25 transition"></div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 md:py-28 px-6 bg-white">
        <h2 className="text-4xl sm:text-5xl font-extrabold text-center mb-16">What Our Clients Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 max-w-7xl mx-auto">
          <motion.div whileHover={{ scale: 1.02 }} className="bg-gray-100 p-6 rounded-3xl shadow-xl text-center">
            <p className="text-gray-700 mb-4">“Red Velvet turned our wedding into a cinematic story. Absolutely stunning work!”</p>
            <h4 className="font-semibold">- Priya Sharma</h4>
          </motion.div>
          <motion.div whileHover={{ scale: 1.02 }} className="bg-gray-100 p-6 rounded-3xl shadow-xl text-center">
            <p className="text-gray-700 mb-4">“Professional, creative, and detail-oriented. Highly recommended for event coverage.”</p>
            <h4 className="font-semibold">- Rajesh Thapa</h4>
          </motion.div>
          <motion.div whileHover={{ scale: 1.02 }} className="bg-gray-100 p-6 rounded-3xl shadow-xl text-center">
            <p className="text-gray-700 mb-4">“The production shoots were flawless. Their team delivers cinematic quality every time.”</p>
            <h4 className="font-semibold">- Sita Koirala</h4>
          </motion.div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 px-6 text-center bg-red-600 text-white">
        <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6">Ready to Capture Your Moments?</h2>
        <p className="max-w-2xl mx-auto mb-8 text-lg sm:text-xl">Book a session today and bring your story to life with Red Velvet Studios.</p>
        <a href="/contact" className="px-10 py-4 bg-white text-red-600 font-semibold rounded-2xl shadow-2xl hover:shadow-red-500/50 transition transform hover:-translate-y-1 inline-block">
          Book Now
        </a>
      </section>

    </div>
  );
};