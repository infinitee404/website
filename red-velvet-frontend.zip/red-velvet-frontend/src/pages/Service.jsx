// ==========================
// Services.jsx - Premium Services Page (No Navbar/Footer)
// ==========================

import React from "react";

export const Services = () => {
  const services = [
    {
      id: 1,
      title: "Event Photography",
      description: "Capture every emotion and moment with cinematic precision, from weddings to corporate events.",
      icon: "📸"
    },
    {
      id: 2,
      title: "Videography",
      description: "Cinematic storytelling, highlight reels, brand films, and fully edited professional videos.",
      icon: "🎥"
    },
    {
      id: 3,
      title: "Production Shoots",
      description: "Commercials, music videos, product promotions — high-end production with modern flair.",
      icon: "🎬"
    },
    {
      id: 4,
      title: "Drone Photography",
      description: "Capture breathtaking aerial views for events, real estate, and cinematic shots.",
      icon: "🚁"
    },
    {
      id: 5,
      title: "Photo Editing & Retouching",
      description: "Professional editing to enhance every image for print or digital use.",
      icon: "🖌️"
    },
    {
      id: 6,
      title: "Commercial Production",
      description: "Full-scale commercial and brand video production for marketing campaigns.",
      icon: "🏢"
    }
  ];

  return (
    <div className="font-sans text-gray-900 bg-white px-4 md:px-6 py-20 max-w-7xl mx-auto">
      <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-center mb-16">Our Services</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10">
        {services.map(service => (
          <div key={service.id} className="bg-gray-50 p-8 rounded-3xl shadow-2xl text-center hover:scale-105 transition transform">
            <div className="text-5xl mb-4">{service.icon}</div>
            <h3 className="text-2xl sm:text-3xl font-semibold mb-3">{service.title}</h3>
            <p className="text-gray-700 text-base sm:text-lg">{service.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};