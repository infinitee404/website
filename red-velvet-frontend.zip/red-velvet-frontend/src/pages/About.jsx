// ==========================
// About.jsx - Premium About Page (No Navbar/Footer)
// ==========================

import React from "react";

export const About = () => {
  return (
    <div className="font-sans text-gray-900 bg-white px-4 md:px-6 py-20 max-w-7xl mx-auto">
      {/* Hero / About Intro */}
      <section className="text-center mb-20">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-6">About Red Velvet Studios</h1>
        <p className="max-w-3xl mx-auto text-gray-700 text-base sm:text-lg md:text-xl">
          Red Velvet Studios is dedicated to capturing your most cherished moments and transforming them into cinematic memories. Our team of creative professionals specializes in photography and videography that tells a story.
        </p>
      </section>

      {/* Mission & Vision */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20">
        <div className="bg-gray-50 p-8 rounded-3xl shadow-2xl text-center">
          <h2 className="text-3xl sm:text-4xl font-semibold mb-4">Our Mission</h2>
          <p className="text-gray-700">To provide top-tier photography and videography services that capture the essence of every moment with creativity, precision, and cinematic quality.</p>
        </div>
        <div className="bg-gray-50 p-8 rounded-3xl shadow-2xl text-center">
          <h2 className="text-3xl sm:text-4xl font-semibold mb-4">Our Vision</h2>
          <p className="text-gray-700">To be recognized as the leading studio for professional event and production photography & videography, setting a benchmark for storytelling excellence.</p>
        </div>
      </section>

      {/* Team Section */}
      <section className="mb-20">
        <h2 className="text-4xl sm:text-5xl font-extrabold text-center mb-12">Meet Our Team</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-gray-50 rounded-3xl shadow-2xl p-6 text-center hover:scale-105 transition transform">
              <div className="h-40 w-40 mx-auto rounded-full overflow-hidden mb-4">
                <img src={`https://source.unsplash.com/collection/888146/400x400?sig=${i}`} alt={`Team member ${i+1}`} className="w-full h-full object-cover" />
              </div>
              <h3 className="text-2xl sm:text-2xl font-semibold mb-2">Team Member {i+1}</h3>
              <p className="text-gray-700">Photographer / Videographer</p>
            </div>
          ))}
        </div>
      </section>

      {/* Company Story / Timeline Section */}
      <section className="mb-20">
        <h2 className="text-4xl sm:text-5xl font-extrabold text-center mb-12">Our Story</h2>
        <div className="relative max-w-4xl mx-auto">
          <div className="border-l-2 border-red-600 absolute h-full left-1/2 transform -translate-x-1/2"></div>
          {[
            { year: '2015', event: 'Founded Red Velvet Studios with a vision to capture cinematic moments.' },
            { year: '2017', event: 'Expanded into commercial production and music videos.' },
            { year: '2020', event: 'Served over 200+ events with 5-star client satisfaction.' },
            { year: '2023', event: 'Launched premium event packages and team expansion.' }
          ].map((item, i) => (
            <div key={i} className={`mb-10 flex ${i % 2 === 0 ? 'justify-start' : 'justify-end'} items-center w-full` }>
              <div className="bg-red-600 text-white p-4 rounded-lg shadow-lg w-64 text-center">
                <h3 className="font-semibold text-lg">{item.year}</h3>
                <p className="text-sm mt-2">{item.event}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
