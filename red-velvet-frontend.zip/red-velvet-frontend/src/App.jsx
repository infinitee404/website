import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Navbar } from "./components/Navbar";
import { Footer } from "./components/Footer";
import { Home } from "./pages/Home";
import { Portfolio } from "./pages/Portfolio";
import { Services } from "./pages/Service";
import { About } from "./pages/About";
import { Contact } from "./pages/Contact";


export default function App() {
return (
<Router>
<Navbar />


<div className="pt-20"> {/* To avoid hiding content behind Navbar */}
<Routes>
<Route path="/" element={<Home />} />
<Route path="/portfolio" element={<Portfolio />} />
<Route path="/services" element={<Services />} />
<Route path="/about" element={<About />} />
<Route path="/contact" element={<Contact />} />
{/* Contact page will be added later */}
</Routes>
</div>


<Footer />
</Router>
);
}