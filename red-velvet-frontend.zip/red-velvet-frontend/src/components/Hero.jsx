export default function Hero() {
  return (
    <section className="relative h-[70vh] bg-black text-white flex items-center" id="home">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-4xl md:text-6xl font-extrabold">Red Velvet</h2>
            <p className="mt-4 text-lg">
              Cinematic production & event photography — we capture the moments that move you.
            </p>
            <a
              href="#contact"
              className="inline-block mt-6 px-6 py-3 bg-red-600 rounded-lg text-white"
            >
              Book a Shoot
            </a>
          </div>

          <div className="h-80 bg-gray-800 rounded-xl flex items-center justify-center opacity-70">
            Hero Image / Video
          </div>
        </div>
      </div>
    </section>
  );
}
