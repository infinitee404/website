export default function Gallery() {
  return (
    <section id="portfolio" className="py-16 bg-gray-50">
      <div className="max-w-6xl mx-auto px-6">
        <h3 className="text-3xl font-semibold">Portfolio</h3>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-6">
          <div className="bg-gray-300 h-40 rounded flex items-center justify-center">
            Photo
          </div>
          <div className="bg-gray-300 h-40 rounded flex items-center justify-center">
            Video
          </div>
          <div className="bg-gray-300 h-40 rounded flex items-center justify-center">
            Photo
          </div>
        </div>
      </div>
    </section>
  );
}
