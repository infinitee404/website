export default function About() {
  return (
    <section id="about" className="py-16">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h3 className="text-3xl font-semibold">About Red Velvet</h3>
        <p className="mt-4 text-lg">
          Red Velvet blends cinematic production techniques with storytelling visuals — delivering
          unforgettable event coverage and high-end production shoots.
        </p>
      </div>
    </section>
  );
}
