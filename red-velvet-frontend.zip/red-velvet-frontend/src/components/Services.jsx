const services = [
  { title: "Event Photography", desc: "Weddings, corporate, concerts, candid & editorial." },
  { title: "Videography", desc: "Highlight reels, multi-cam coverage, livestreaming." },
  { title: "Production Shoots", desc: "Product commercials, brand films, BTS." },
  { title: "Editing & Color Grade", desc: "Professional editing, color grading & delivery." },
];

export default function Services() {
  return (
    <section id="services" className="py-16">
      <div className="max-w-6xl mx-auto px-6">
        <h3 className="text-3xl font-semibold">Services</h3>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
          {services.map((s, i) => (
            <div key={i} className="p-6 border rounded-xl shadow-sm">
              <h4 className="font-bold text-lg">{s.title}</h4>
              <p className="text-sm mt-2">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
