// Navbar.jsx
// ==========================
export const Navbar = () => {
return (
<nav className="w-full fixed top-0 left-0 z-50 bg-white/80 backdrop-blur-lg shadow-sm py-4 px-6 flex justify-between items-center">
    <div className="text-2xl font-bold tracking-wide">Red Velvet</div>
    <ul className="flex space-x-8 text-lg font-medium">
        <li><a href="/" className="hover:text-red-600 transition">Home</a></li>
        <li><a href="/portfolio" className="hover:text-red-600 transition">Portfolio</a></li>
        <li><a href="/services" className="hover:text-red-600 transition">Services</a></li>
        <li><a href="/about" className="hover:text-red-600 transition">About</a></li>
        <li><a href="/contact" className="hover:text-red-600 transition">Contact</a></li>
    </ul>
</nav>
);
};