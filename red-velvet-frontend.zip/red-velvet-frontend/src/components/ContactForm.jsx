import { useState } from "react";

export default function ContactForm() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
    service: "",
  });

  return (
    <section id="contact" className="py-16 bg-white">
      <div className="max-w-3xl mx-auto px-6">
        <h3 className="text-3xl font-semibold">Book a Shoot</h3>

        <div className="grid gap-4 mt-6">
          <input
            className="p-3 border rounded"
            placeholder="Full Name"
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
          />

          <input
            className="p-3 border rounded"
            placeholder="Email"
            value={form.email}
            onChange={e => setForm({ ...form, email: e.target.value })}
          />

          <input
            className="p-3 border rounded"
            placeholder="Phone (optional)"
            value={form.phone}
            onChange={e => setForm({ ...form, phone: e.target.value })}
          />

          <select
            className="p-3 border rounded"
            value={form.service}
            onChange={e => setForm({ ...form, service: e.target.value })}
          >
            <option value="">Choose service</option>
            <option>Event Photography</option>
            <option>Videography</option>
            <option>Production Shoot</option>
            <option>Editing</option>
          </select>

          <textarea
            className="p-3 border rounded h-32"
            placeholder="Tell us about your project..."
            value={form.message}
            onChange={e => setForm({ ...form, message: e.target.value })}
          />

          <button className="bg-red-600 text-white px-6 py-3 rounded w-max">
            Send Message
          </button>
        </div>
      </div>
    </section>
  );
}
